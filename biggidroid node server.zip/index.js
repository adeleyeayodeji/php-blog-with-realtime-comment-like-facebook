const app = require("express")();
var cors = require("cors");
app.use(cors());
const server = require("http").createServer(app);
const io = require("socket.io")(server);
io.on("connection", (client) => {
  console.log("Someone just connected");
  client.on("message", (data) => {
    console.log("We are good", data);
    //Insert message
    // client.emit("message", {
    //   type: "insert",
    //   data: data,
    // });
    io.emit("broadcast", {
      type: "insert",
      data: data,
    });

    //Notify
    client.broadcast.emit("alert", {
      type: "alert",
      data: data,
    });
  });
  client.on("disconnect", () => {
    console.log("Someone disconnect");
  });
});
server.listen(3000);
